<?php
$pdo=new PDO('mysql:host=localhost;dbname=micro_blog','root','root');
?>